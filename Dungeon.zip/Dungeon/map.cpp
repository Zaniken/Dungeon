#include <string>
#include <iostream>
#include "functions.h"
#include<time.h> 
#include <stdio.h> 
#include <stdlib.h> 
using namespace std;


// this prints to console a 2dim array;
void printMap(int map[mapX][mapY],struct Hero h){
	
	for(int i = 0; i < mapX; i++){
		for(int j = 0; j<mapY; j++){
			
			
			if(h.x==j&&h.y==i){
				cout<<"0 ";
				map[i][j]=9;
			}
			else
			cout<<map[i][j]<<" ";
			
		}
		cout<<"\n";
	}
	
}
void testing(int map[mapX][mapY]){
	for(int i = 0; i < mapX; i++){
		for(int j = 0; j<mapY; j++){
			map[i][j]=0;
		}}
}

//initializes the map 

void initializeMap(int map[mapX][mapY]){
	//filling map array with random numbers
	srand(time(NULL));
	int upper = 2, lower =1;
	for(int i =0; i<mapX;i++){
		for(int j=0;j<mapY;j++){
			
				int num = (rand() % (upper - lower + 1)) + lower; 
				map[i][j]=num;
				//cout<<num;
			
			
		}
	}
	
	
}

bool checkEnd(int map[mapX][mapY]){
	bool end = true;
	for(int i =0; i<mapX;i++){
	for(int j=0;j<mapY;j++){
		if(map[i][j]==1){
			end = false;
			//cout<<"test";
		}
		
	}}
	return end;
}


