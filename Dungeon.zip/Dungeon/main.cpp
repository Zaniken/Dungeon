//Dungeon Crawler for C++
//Zaniken Gurule

/*
Well i did this all on my own if that counts for anything haha.


Code Quality (including user interface)	: um I made comments on my code and it runs so maybe 7/10 

Logical use of multiple files: I use a header file and have it protected and I have must functions in seperate map file.

Overall Functionality (Could I break it): I havent been able to break it.

Logical use of enum type: I didnt do this so no points.


Proper use of static variable: I have a static counter that counts moves made.

Logical use of a struct: My hero is made in a struct

Logical use of random number generator: Random number asings 1 or 2s in each map array slot.


*/



#include <string>
#include <iostream>
#include "functions.h"
#include<time.h> 
#include <stdio.h> 
#include <stdlib.h> 

using namespace std;




bool moveLeft(struct Hero h){
	
	if(h.x-1<0)
	{
		
		return false;
	}
	else
		return true;
	
}

bool moveRight(struct Hero h){
	if(h.x+1>mapX-1)
	{
		return false;
	}
	else
		return true;
	
}

bool moveUp(struct Hero h){
	if(h.y-1<0)
	{
		return false;
	}
	else
		return true;
	
}
bool moveDown(struct Hero h){
	if(h.y-1>mapY-1)
	{
		return false;
	}
	else
		return true;
	
}








int main( )
{	static int count = 0; 
	//Create a hero
	struct Hero h1;
	h1.health=10;
	h1.x=0;
	h1.y=0;

	//create the map array
	int test[mapX][mapY];
	//fill the map with 2 and 1s
	initializeMap(test);
	
	
	
	cout<<"Didnt really implement any game mechanics so to win pick up all the 1s, you are the 0 \n";
	
	printMap(test,h1);
	
	cout<<"\n ****************** \n";
	
	
	
	

	
	
	char t1;
	while(!checkEnd(test)){
		cout<<"Give a WASD input \n";
		 t1 = getchar();
		 
		 switch(t1){
			 
			case 'w' :
					if(moveUp(h1)){
					h1.y-=1;
					printMap(test,h1);
					cout<<"\n ****************** Moved Up \n";
					count++;
												}
				break;
			case 's' :
					if(moveDown(h1)){
					h1.y+=1;
					printMap(test,h1);
					cout<<"\n ****************** Moved Down \n";
					count++;
	}				
				break;
				
			case 'd':
				if(moveRight(h1)){
					h1.x+=1;
					printMap(test,h1);
					cout<<"\n ****************** Moved right \n";
					count++;
	}
				break;
				
			case 'a' : 
				if(moveLeft(h1)){
					h1.x-=1;
					printMap(test,h1);
					cout<<"\n ****************** Moved Left \n";
					count++;
	}
				break;
				
			default: cout<<"Invalid input: ";
			  
		 }
		
	}

	cout<<" \n Congrats you just won the worst game ever made :)";
	cout<<"\n It took you this many moves: "<<count;
	
	
	
	//intro 
	string name;
	//fileRead("image.txt");
	//cout<<"Please type in your name: ";
	//cin>>name;
	//fileRead("mt.txt");
	//cout<<"\n Sir "<<name<<" you have been tasked by the king with clearing out a mine shaft.\n Goblins have been breeding in the deep dark dank tunnels. \n Take care of it";
	//intro end
	
	

	
}
	
