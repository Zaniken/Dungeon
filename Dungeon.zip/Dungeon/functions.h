#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <string>



const int mapX = 5;
const int mapY = 5;
//extern int test[mapX][mapY];
void testing(int map[mapX][mapY]);
void initializeMap(int map[mapX][mapY]);
void printMap(int map[mapX][mapY],struct Hero h);
bool checkEnd(int map[mapX][mapY]);

struct Hero{
	int health;
	int x;
	int y;
	
};

int fileRead(std::string fileNameString);
void screenScroll();
//void setCalories(double mass, int planet, double distance);
#endif